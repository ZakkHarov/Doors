alter table DOORS_ORDER add PLACEMENT_CATEGORY integer not null default 0 ;
