alter table DOORS_ORDER add TYPE_ varchar(255) not null default '' ;
alter table DOORS_ORDER add HEIGHT decimal(19, 2) ;
alter table DOORS_ORDER add WIDTH decimal(19, 2) ;
alter table DOORS_ORDER add OPENING varchar(50) ;
