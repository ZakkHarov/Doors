alter table DOORS_ORDER alter column DOOR_ID uniqueidentifier ;
