alter table DOORS_ORDER add PRICE decimal(19, 2) not null default 0 ;
