alter table DOORS_ORDER add TOP_LOCK varchar(255) ;
alter table DOORS_ORDER add BOTTOM_LOCK varchar(255) ;
alter table DOORS_ORDER add TOP_ONLAY varchar(255) ;
alter table DOORS_ORDER add BOTTOM_ONLAY varchar(255) ;
alter table DOORS_ORDER add HANDLE varchar(255) ;
alter table DOORS_ORDER add CYLINDER varchar(255) ;
