alter table DOORS_ORDER add MASTER integer ;
alter table DOORS_ORDER add PAYED tinyint ;
