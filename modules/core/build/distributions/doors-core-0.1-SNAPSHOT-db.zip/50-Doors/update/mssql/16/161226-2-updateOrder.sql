alter table DOORS_ORDER add STATUS integer not null default 1 ;
