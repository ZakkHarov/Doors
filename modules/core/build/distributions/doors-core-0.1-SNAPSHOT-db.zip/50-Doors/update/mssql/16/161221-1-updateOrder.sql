alter table DOORS_ORDER drop constraint DF__DOORS_ORD__TYPE___04E4BC85 ;
