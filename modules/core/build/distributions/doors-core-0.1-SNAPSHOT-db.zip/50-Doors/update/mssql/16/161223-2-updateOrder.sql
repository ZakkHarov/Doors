alter table DOORS_ORDER add INTERNAL_DECORATION varchar(max) ;
alter table DOORS_ORDER add EXTERNAL_DECORATION varchar(max) ;
