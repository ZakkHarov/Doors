alter table DOORS_ORDER alter column PRICE decimal(2, 2) ;
