alter table DOORS_ORDER drop column MOLDING ;
