alter table DOORS_ORDER add ISOLATION_ tinyint ;
alter table DOORS_ORDER add PEEPHOLE tinyint ;
alter table DOORS_ORDER add MOLDING tinyint ;
alter table DOORS_ORDER add TRIM_ tinyint ;
alter table DOORS_ORDER add DISMANTLING tinyint ;
