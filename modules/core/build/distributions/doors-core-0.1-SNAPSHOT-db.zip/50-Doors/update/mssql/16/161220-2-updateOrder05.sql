alter table DOORS_ORDER add LOOP_NUMBER varchar(255) not null default '' ;
