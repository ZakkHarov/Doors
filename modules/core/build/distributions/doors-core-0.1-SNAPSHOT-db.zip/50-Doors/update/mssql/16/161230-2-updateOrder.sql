alter table DOORS_ORDER alter column HEIGHT integer ;
alter table DOORS_ORDER alter column WIDTH integer ;
